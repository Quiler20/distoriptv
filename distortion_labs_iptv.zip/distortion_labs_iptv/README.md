# Distortion Labs IPTV (Flutter, solo Android)

Se compila con GitHub Actions: sube este zip a la raíz de tu repo junto con el workflow `build.yml`.
El workflow genera la parte Android, la configura y compila el APK.

Funciones: listas por URL / pegar M3U / archivo / Xtream, favoritos, menú de canales en pantalla completa,
ampliar/reducir, bloqueo táctil, modo audio con pantalla apagada, limpiar caché.
